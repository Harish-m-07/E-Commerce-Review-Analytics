import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter
from wordcloud import STOPWORDS
from io import BytesIO
import base64

# Convert matplotlib figure → base64 string
def encode_chart():
    buf = BytesIO()
    plt.savefig(buf, format="png", bbox_inches="tight")
    buf.seek(0)
    encoded = base64.b64encode(buf.getvalue()).decode("utf-8")
    buf.close()
    plt.close()
    return encoded


# ==============================================================
# A) Rating Distribution Chart
# ==============================================================
def generate_rating_distribution(df):
    plt.figure(figsize=(6,4))
    rating_counts = df["rating"].value_counts().sort_index()

    plt.bar(rating_counts.index.astype(str), rating_counts.values, color="#4C7CF5")
    plt.title("Rating Distribution")
    plt.xlabel("Rating")
    plt.ylabel("Number of Reviews")

    return encode_chart()


# ==============================================================
# B) Rating Trend Over Time Chart
# ==============================================================
def generate_rating_trend(df):
    df = df.copy()
    if "date" in df.columns:
        df["review_date"] = pd.to_datetime(df["review_date"], errors="coerce")
        df = df.dropna(subset=["date"])

    trend = df.groupby(df["review_date"].dt.to_period("M"))["rating"].mean()

    plt.figure(figsize=(7,4))
    trend.plot(kind="line", marker="o", color="#8A4FF5")
    plt.title("Average Rating Over Time")
    plt.xlabel("Month")
    plt.ylabel("Avg Rating")

    return encode_chart()


# ==============================================================
# C) Positive Word Frequency Chart
# ==============================================================
def generate_positive_words(df):
    positive_words = []
    stopwords = set(STOPWORDS)

    for text in df["review_text"]:
        if isinstance(text, str):
            words = [w.lower() for w in text.split() if w.lower() not in stopwords]
            positive_words.extend(words)

    word_counts = Counter(positive_words).most_common(12)
    if not word_counts:
        return None

    words, counts = zip(*word_counts)

    plt.figure(figsize=(7,4))
    plt.bar(words, counts, color="#00C8A0")
    plt.xticks(rotation=45)
    plt.title("Most Frequent Positive Words")
    plt.ylabel("Frequency")

    return encode_chart()


# ==============================================================
# D) Sentiment Breakdown Pie Chart
# ==============================================================
def generate_sentiment_breakdown(df):
    if "sentiment" not in df.columns:
        return None

    sentiment_counts = df["sentiment"].value_counts()

    plt.figure(figsize=(6,6))
    plt.pie(
        sentiment_counts,
        labels=sentiment_counts.index,
        autopct="%1.1f%%",
        colors=["#5C8DF7", "#00C8A0", "#F06A6A"]
    )
    plt.title("Sentiment Breakdown")

    return encode_chart()


# ==============================================================
# E) Review Volume by Category Chart
# ==============================================================
def generate_category_volume(df):
    if "categories" not in df.columns:
        return None

    category_counts = df["categories"].value_counts().head(10)

    plt.figure(figsize=(7,4))
    category_counts.plot(kind="bar", color="#F5A623")
    plt.title("Review Volume by Category")
    plt.xlabel("Category")
    plt.ylabel("Review Count")

    return encode_chart()