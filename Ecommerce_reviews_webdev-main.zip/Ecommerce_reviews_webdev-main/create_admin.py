from pymongo import MongoClient
from werkzeug.security import generate_password_hash
import os

# Use the same values you use in app.py
MONGO_URI = os.getenv(
    "MONGO_URI",
    "mongodb+srv://carthikn9080_db_user:user1234@cluster0.uasp58v.mongodb.net/?appName=Cluster0",
)
DB_NAME = "review_app"        # or your actual DB name
USERS_COLLECTION = "users"

client = MongoClient(MONGO_URI)
db = client[DB_NAME]
users_col = db[USERS_COLLECTION]

email = "admin@iu.edu"   # admin login email
name = "IU Admin"
password = "Admin@123"        # choose whatever you like

existing = users_col.find_one({"email": email})
if existing:
    print("Admin already exists with this email.")
else:
    doc = {
        "email": email,
        "name": name,
        "password_hash": generate_password_hash(password),
        "role": "admin",
    }
    users_col.insert_one(doc)
    print("Admin created successfully!")
    print(f"Login with: {email} / {password}")