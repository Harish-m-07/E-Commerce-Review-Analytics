import csv
from datetime import datetime
from textblob import TextBlob
from pymongo import MongoClient
import re

MONGO_URI = "mongodb+srv://carthikn9080_db_user:user1234@cluster0.uasp58v.mongodb.net/?appName=Cluster0"
DB_NAME = "review_app"
COLLECTION_NAME = "reviews"
CSV_PATH = "/Users/karthik/Downloads/ADT/final_project2/cleaned_amazon_reviews.csv"

client = MongoClient(MONGO_URI)
db = client[DB_NAME]
col = db[COLLECTION_NAME]


def analyze_sentiment(text: str) -> str:
    polarity = TextBlob(text).sentiment.polarity
    if polarity > 0.1:
        return "positive"
    elif polarity < -0.1:
        return "negative"
    return "neutral"


def load_csv():
    with open(CSV_PATH, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        docs = []
        for row in reader:
            try:
                rating = float(row["reviews.rating"])
            except (ValueError, TypeError):
                continue

            try:
                review_date = datetime.fromisoformat(str(row["reviews.date"]))
            except Exception:
                review_date = None

            cats_raw = row.get("categories") or ""
            if isinstance(cats_raw, str):
               # Remove brackets and quotes: ["Tablets"] → Tablets
                cleaned = re.sub(r"[\[\]'\"]", "", cats_raw)
               # Split into list and strip spaces
                categories = [c.strip() for c in cleaned.split(",") if c.strip()]
               # Remove accidental duplicates inside the row
                categories = list(dict.fromkeys(categories))
            else:
                categories = []

            doc = {
                "original_id": row.get("id"),
                "product_name": row.get("name"),
                "asin": row.get("asin"),
                "brand": row.get("brand"),
                "categories": categories,
                "manufacturer": row.get("manufacturer"),
                "rating": rating,
                "review_text": row.get("reviews.text", ""),
                "review_title": row.get("reviews.title", ""),
                "username": row.get("reviews.username", "Anonymous"),
                "review_date": review_date,
            }
            doc["sentiment"] = analyze_sentiment(doc["review_text"])
            docs.append(doc)

        if docs:
            col.delete_many({})  # clear old data if any
            col.insert_many(docs)
            print(f"Inserted {len(docs)} reviews.")


if __name__ == "__main__":
    load_csv()