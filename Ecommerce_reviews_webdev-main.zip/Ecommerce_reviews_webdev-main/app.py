from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session,
)
from pymongo import MongoClient
from bson.objectid import ObjectId
from textblob import TextBlob
from collections import Counter
from io import BytesIO
import pandas as pd
import base64
import matplotlib
matplotlib.use("Agg")  # no GUI
import matplotlib.pyplot as plt
from werkzeug.security import generate_password_hash, check_password_hash
import os
from functools import wraps
from dashboard_utils import (
    generate_rating_distribution,
    generate_rating_trend,
    generate_positive_words,
    generate_sentiment_breakdown,
    generate_category_volume
)

# ---------------------------------------------------
# Flask app
# ---------------------------------------------------
app = Flask(__name__)
app.secret_key = "change_this_to_a_long_random_secret"

# ---------------------------------------------------
# MongoDB connection (Atlas or local)
# ---------------------------------------------------
MONGO_URI = os.getenv(
    "MONGO_URI",
    # replace this with your Atlas connection string:
    "mongodb+srv://carthikn9080_db_user:user1234@cluster0.uasp58v.mongodb.net/?appName=Cluster0",
)

DB_NAME = "review_app"         # use your database name
REVIEWS_COLLECTION = "reviews" # use your collection name
USERS_COLLECTION = "users"

client = MongoClient(MONGO_URI)
db = client[DB_NAME]
reviews_col = db[REVIEWS_COLLECTION]
users_col = db[USERS_COLLECTION]

# ---------------------------------------------------
# Auth helpers
# ---------------------------------------------------
def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return users_col.find_one({"_id": ObjectId(user_id)})

@app.context_processor
def inject_user():
    return {"current_user": get_current_user()}

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in to access this page.", "error")
            return redirect(url_for("login", next=request.url))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = get_current_user()
        if not user or user.get("role") != "admin":
            flash("Admin access required.", "error")
            return redirect(url_for("home"))
        return f(*args, **kwargs)
    return wrapper

# ---------------------------------------------------
# Utility functions
# ---------------------------------------------------
def analyze_sentiment(text: str) -> str:
    polarity = TextBlob(text).sentiment.polarity
    if polarity > 0.1:
        return "positive"
    elif polarity < -0.1:
        return "negative"
    return "neutral"

def get_categories():
    cats = reviews_col.distinct("categories")
    flat = []
    for c in cats:
        if isinstance(c, list):
            flat.extend(c)
        elif isinstance(c, str):
            flat.append(c)
    return sorted(set(flat))

def generate_rating_chart():
    pipeline = [
        {"$group": {"_id": "$brand", "avg_rating": {"$avg": "$rating"}}},
        {"$sort": {"avg_rating": -1}},
        {"$limit": 8},
    ]
    data = list(reviews_col.aggregate(pipeline))
    if not data:
        return None

    brands = [d["_id"] or "Unknown" for d in data]
    ratings = [round(d["avg_rating"], 2) for d in data]

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.bar(brands, ratings)
    ax.set_ylim(0, 5)
    ax.set_ylabel("Average Rating")
    ax.set_title("Average Rating by Brand (Top 8)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    buf = BytesIO()
    plt.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.getvalue()).decode("utf-8")

def generate_word_freq_chart():
    negative_reviews = reviews_col.find({"sentiment": "negative"}, {"review_text": 1})
    text = " ".join([r.get("review_text", "") for r in negative_reviews])

    if not text.strip():
        return None

    words = [
        w.lower()
        for w in text.split()
        if w.isalpha() and len(w) > 3
    ]
    counts = Counter(words)
    common = counts.most_common(15)
    if not common:
        return None

    labels, values = zip(*common)

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.bar(labels, values)
    ax.set_ylabel("Frequency")
    ax.set_title("Most Frequent Words in Negative Reviews")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    buf = BytesIO()
    plt.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.getvalue()).decode("utf-8")

# ---------------------------------------------------
# Routes - Auth
# ---------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        name = request.form.get("name", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")

        if not email or not password or not name:
            flash("All fields are required.", "error")
            return redirect(url_for("register"))
        if password != confirm:
            flash("Passwords do not match.", "error")
            return redirect(url_for("register"))

        existing = users_col.find_one({"email": email})
        if existing:
            flash("Email already registered. Please log in.", "error")
            return redirect(url_for("login"))

        # first user becomes admin
        # everyone who registers through the UI is a normal user
        role = "user"

        user_doc = {
            "email": email,
            "name": name,
            "password_hash": generate_password_hash(password),
            "role": role,
        }
        result = users_col.insert_one(user_doc)
        session["user_id"] = str(result.inserted_id)
        flash(f"Welcome, {name}!", "success")
        return redirect(url_for("home"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = users_col.find_one({"email": email})
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Invalid email or password.", "error")
            return redirect(url_for("login"))

        session["user_id"] = str(user["_id"])
        flash(f"Welcome back, {user['name']}!", "success")
        next_url = request.args.get("next")
        return redirect(next_url or url_for("home"))

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("home"))

# ---------------------------------------------------
# Routes - Pages
# ---------------------------------------------------
@app.route("/")
def home():
    # Use a few quick stats for the hero section
    total_reviews = reviews_col.count_documents({})
    brands_count = len(list(reviews_col.distinct("brand")))
    avg_rating_doc = list(
        reviews_col.aggregate([{"$group": {"_id": None, "avg": {"$avg": "$rating"}}}])
    )
    avg_rating = round(avg_rating_doc[0]["avg"], 2) if avg_rating_doc else None

    return render_template(
        "home.html",
        total_reviews=total_reviews,
        brands_count=brands_count,
        avg_rating=avg_rating,
    )

@app.route("/reviews")
def reviews():
    q_keyword = request.args.get("q", "").strip()
    q_category = request.args.get("category", "").strip()
    q_min_rating = request.args.get("min_rating", "").strip()
    q_max_rating = request.args.get("max_rating", "").strip()
    q_sentiment = request.args.get("sentiment", "").strip()

    query = {}

    if q_keyword:
        query["$or"] = [
            {"review_text": {"$regex": q_keyword, "$options": "i"}},
            {"review_title": {"$regex": q_keyword, "$options": "i"}},
            {"product_name": {"$regex": q_keyword, "$options": "i"}},
        ]

    if q_category:
        query["categories"] = q_category

    rating_filter = {}
    if q_min_rating:
        try:
            rating_filter["$gte"] = float(q_min_rating)
        except ValueError:
            pass
    if q_max_rating:
        try:
            rating_filter["$lte"] = float(q_max_rating)
        except ValueError:
            pass
    if rating_filter:
        query["rating"] = rating_filter

    if q_sentiment:
        query["sentiment"] = q_sentiment

    reviews_list = list(
        reviews_col.find(query).sort("review_date", -1).limit(200)
    )

    categories = get_categories()

    return render_template(
        "reviews.html",
        reviews=reviews_list,
        categories=categories,
        filters={
            "q": q_keyword,
            "category": q_category,
            "min_rating": q_min_rating,
            "max_rating": q_max_rating,
            "sentiment": q_sentiment,
        },
    )

# ---------------------------------------------------
# Routes - CRUD Reviews
# ---------------------------------------------------
@app.route("/review/new", methods=["GET", "POST"])
@login_required
def create_review():
    user = get_current_user()
    if request.method == "POST":
        product_name = request.form.get("product_name")
        asin = request.form.get("asin")
        brand = request.form.get("brand")
        category = request.form.get("category")
        manufacturer = request.form.get("manufacturer")
        rating = float(request.form.get("rating") or 0)
        review_title = request.form.get("review_title")
        review_text = request.form.get("review_text")
        username = user["name"]

        sentiment = analyze_sentiment(review_text)

        doc = {
            "product_name": product_name,
            "asin": asin,
            "brand": brand,
            "categories": [c.strip() for c in category.split(",") if c.strip()],
            "manufacturer": manufacturer,
            "rating": rating,
            "review_title": review_title,
            "review_text": review_text,
            "username": username,
            "user_id": str(user["_id"]),
            "sentiment": sentiment,
        }

        reviews_col.insert_one(doc)
        flash("Review added successfully!", "success")
        return redirect(url_for("reviews"))

    return render_template("review_form.html", review=None)

@app.route("/review/<review_id>/edit", methods=["GET", "POST"])
@login_required
def edit_review(review_id):
    user = get_current_user()
    review = reviews_col.find_one({"_id": ObjectId(review_id)})
    if not review:
        flash("Review not found", "error")
        return redirect(url_for("reviews"))

    # permission: admin or owner
    if user["role"] != "admin" and review.get("user_id") != str(user["_id"]):
        flash("You do not have permission to edit this review.", "error")
        return redirect(url_for("reviews"))

    if request.method == "POST":
        product_name = request.form.get("product_name")
        asin = request.form.get("asin")
        brand = request.form.get("brand")
        category = request.form.get("category")
        manufacturer = request.form.get("manufacturer")
        rating = float(request.form.get("rating") or 0)
        review_title = request.form.get("review_title")
        review_text = request.form.get("review_text")

        sentiment = analyze_sentiment(review_text)

        updates = {
            "product_name": product_name,
            "asin": asin,
            "brand": brand,
            "categories": [c.strip() for c in category.split(",") if c.strip()],
            "manufacturer": manufacturer,
            "rating": rating,
            "review_title": review_title,
            "review_text": review_text,
            "sentiment": sentiment,
        }

        reviews_col.update_one({"_id": ObjectId(review_id)}, {"$set": updates})
        flash("Review updated successfully!", "success")
        return redirect(url_for("reviews"))

    cats = review.get("categories") or []
    category_str = ", ".join(cats) if isinstance(cats, list) else str(cats)
    review["category_str"] = category_str
    return render_template("review_form.html", review=review)

@app.route("/review/<review_id>/delete", methods=["POST"])
@login_required
def delete_review(review_id):
    user = get_current_user()
    review = reviews_col.find_one({"_id": ObjectId(review_id)})
    if not review:
        flash("Review not found", "error")
        return redirect(url_for("reviews"))

    if user["role"] != "admin" and review.get("user_id") != str(user["_id"]):
        flash("You do not have permission to delete this review.", "error")
        return redirect(url_for("reviews"))

    reviews_col.delete_one({"_id": ObjectId(review_id)})
    flash("Review deleted.", "info")
    return redirect(url_for("reviews"))

# ---------------------------------------------------
# Dashboard - Admin only
# ---------------------------------------------------
@app.route("/dashboard")
@admin_required
def dashboard():
    # ------------------------
    # Basic Metrics
    # ------------------------
    total_reviews = reviews_col.count_documents({})

    avg_rating_doc = list(
        reviews_col.aggregate([
            {"$group": {"_id": None, "avg": {"$avg": "$rating"}}}
        ])
    )
    avg_rating = round(avg_rating_doc[0]["avg"], 2) if avg_rating_doc else None

    # ------------------------
    # Avg rating by category (Top 10)
    # ------------------------
    pipeline = [
        {"$unwind": "$categories"},
        {"$group": {
            "_id": "$categories",
            "avg_rating": {"$avg": "$rating"},
            "count": {"$sum": 1}
        }},
        {"$sort": {"avg_rating": -1}},
        {"$limit": 10},
    ]
    avg_by_cat = list(reviews_col.aggregate(pipeline))

    # ------------------------
    # Load reviews into DataFrame
    # ------------------------
    reviews_list = list(reviews_col.find({}))
    df = pd.DataFrame(reviews_list)

    # ------------------------
    # Generate dashboard charts
    # ------------------------
    chart_rating_dist = generate_rating_distribution(df)
    chart_rating_trend = generate_rating_trend(df)
    chart_positive = generate_positive_words(df)
    chart_sentiment = generate_sentiment_breakdown(df)
    chart_category = generate_category_volume(df)

    # ------------------------
    # Sentiment Summary
    # ------------------------
    sentiment_counts = list(
        reviews_col.aggregate([
            {"$group": {"_id": "$sentiment", "count": {"$sum": 1}}}
        ])
    )
    sentiment_summary = {x["_id"]: x["count"] for x in sentiment_counts}

    # ------------------------
    # Render dashboard template
    # ------------------------
    return render_template(
        "dashboard.html",
        total_reviews=total_reviews,
        avg_rating=avg_rating,
        avg_by_cat=avg_by_cat,

        # New charts
        chart_rating_dist=chart_rating_dist,
        chart_rating_trend=chart_rating_trend,
        chart_positive=chart_positive,
        chart_sentiment=chart_sentiment,
        chart_category=chart_category,

        # Sentiment overview
        sentiment_summary=sentiment_summary
    )
# ---------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True)